import './Spinner.css' ; 

export default function Spinner(){
    return (
       <div className='w-full h-full'>
         <div className="spinner m-auto mt-36 ">
            
            </div>
       </div>
    )
}